const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

// --- Sprites simples (quadrados coloridos) ---
const SPRITES = {
  mario: { color: "red", width: 32, height: 32 },
  donkey: { color: "brown", width: 48, height: 48 },
  princess: { color: "pink", width: 32, height: 48 },
  barrel: { color: "sienna", width: 24, height: 24 },
  platform: { color: "#ccc" },
  ladder: { color: "orange" },
};

const keys = {};
document.addEventListener("keydown", (e) => (keys[e.key] = true));
document.addEventListener("keyup", (e) => (keys[e.key] = false));

const gravity = 0.5;
const floorY = 440;

let score = 0;
let lives = 3;
let gameOver = false;

const player = {
  x: 50,
  y: floorY - SPRITES.mario.height,
  width: SPRITES.mario.width,
  height: SPRITES.mario.height,
  velX: 0,
  velY: 0,
  speed: 3,
  jumping: false,
  onLadder: false,
};

const platforms = [
  { x1: 0, y1: 440, x2: 350, y2: 360 },
  { x1: 350, y1: 360, x2: 100, y2: 280 },
  { x1: 100, y1: 280, x2: 300, y2: 200 },
  { x1: 300, y1: 200, x2: 0, y2: 120 },
];

const ladders = [
  { x: 160, y: 360, height: 80 },
  { x: 270, y: 280, height: 80 },
  { x: 120, y: 200, height: 80 },
];

const donkey = {
  x: 420,
  y: 80,
  width: SPRITES.donkey.width,
  height: SPRITES.donkey.height,
};

const princess = {
  x: 440,
  y: 60,
  width: SPRITES.princess.width,
  height: SPRITES.princess.height,
};

const barrels = [];
const barrelSpawnInterval = 2000;
let lastBarrelSpawn = Date.now();

function spawnBarrel() {
  barrels.push({
    x: donkey.x,
    y: donkey.y + donkey.height - SPRITES.barrel.height,
    width: SPRITES.barrel.width,
    height: SPRITES.barrel.height,
    velX: -2,
    velY: 0,
    rolling: true,
  });
}

function rectsColliding(r1, r2) {
  return !(
    r2.x > r1.x + r1.width ||
    r2.x + r2.width < r1.x ||
    r2.y > r1.y + r1.height ||
    r2.y + r2.height < r1.y
  );
}

function updatePlayer() {
  if (keys["ArrowLeft"]) player.velX = -player.speed;
  else if (keys["ArrowRight"]) player.velX = player.speed;
  else player.velX = 0;

  player.onLadder = false;
  for (let ladder of ladders) {
    if (
      player.x + player.width > ladder.x &&
      player.x < ladder.x + 32 &&
      player.y + player.height > ladder.y &&
      player.y < ladder.y + ladder.height
    ) {
      player.onLadder = true;
      break;
    }
  }

  if (player.onLadder) {
    if (keys["ArrowUp"]) player.y -= player.speed;
    if (keys["ArrowDown"]) player.y += player.speed;
    player.velY = 0;
    player.jumping = false;
  } else {
    player.velY += gravity;
    player.y += player.velY;

    let onPlatform = false;
    for (let platform of platforms) {
      const m = (platform.y2 - platform.y1) / (platform.x2 - platform.x1);
      const b = platform.y1 - m * platform.x1;
      const platYatPlayerX = m * (player.x + player.width / 2) + b;

      if (
        player.y + player.height >= platYatPlayerX - 5 &&
        player.y + player.height <= platYatPlayerX + 5 &&
        player.x + player.width / 2 >= Math.min(platform.x1, platform.x2) &&
        player.x + player.width / 2 <= Math.max(platform.x1, platform.x2)
      ) {
        player.y = platYatPlayerX - player.height;
        player.velY = 0;
        player.jumping = false;
        onPlatform = true;
        break;
      }
    }

    if (!onPlatform && player.y + player.height >= floorY) {
      player.y = floorY - player.height;
      player.velY = 0;
      player.jumping = false;
    }
  }

  if (keys[" "] && !player.jumping && !player.onLadder) {
    player.velY = -10;
    player.jumping = true;
  }

  player.x += player.velX;

  if (player.x < 0) player.x = 0;
  if (player.x + player.width > canvas.width) player.x = canvas.width - player.width;
}

function updateBarrels() {
  const now = Date.now();
  if (now - lastBarrelSpawn > barrelSpawnInterval) {
    spawnBarrel();
    lastBarrelSpawn = now;
  }

  for (let i = barrels.length - 1; i >= 0; i--) {
    const b = barrels[i];
    b.x += b.velX;
    if (b.y + b.height < floorY) {
      b.y += gravity;
    }
    if (b.x + b.width < 0) {
      barrels.splice(i, 1);
      score += 10;
    }
    if (rectsColliding(player, b)) {
      lives--;
      barrels.splice(i, 1);
      if (lives <= 0) {
        gameOver = true;
      }
    }
  }
}

function drawPlatform(platform) {
  ctx.strokeStyle = SPRITES.platform.color;
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(platform.x1, platform.y1);
  ctx.lineTo(platform.x2, platform.y2);
  ctx.stroke();
}

function drawLadder(ladder) {
  ctx.fillStyle = SPRITES.ladder.color;
  ctx.fillRect(ladder.x, ladder.y, 32, ladder.height);
}

function drawRect(obj) {
  ctx.fillStyle = obj.color;
  ctx.fillRect(obj.x, obj.y, obj.width, obj.height);
}

function drawPlayer() {
  ctx.fillStyle = SPRITES.mario.color;
  ctx.fillRect(player.x, player.y, player.width, player.height);
}

function drawDonkey() {
  ctx.fillStyle = SPRITES.donkey.color;
  ctx.fillRect(donkey.x, donkey.y, donkey.width, donkey.height);
}

function drawPrincess() {
  ctx.fillStyle = SPRITES.princess.color;
  ctx.fillRect(princess.x, princess.y, princess.width, princess.height);
}

function drawBarrel(barrel) {
  ctx.fillStyle = SPRITES.barrel.color;
  ctx.fillRect(barrel.x, barrel.y, barrel.width, barrel.height);
}

function drawHUD() {
  ctx.fillStyle = "white";
  ctx.font = "20px monospace";
  ctx.fillText(`Pontos: ${score}`, 10, 30);
  ctx.fillText(`Vidas: ${lives}`, 400, 30);
  if (gameOver) {
    ctx.fillStyle = "red";
    ctx.font = "48px monospace";
    ctx.fillText("GAME OVER", 140, 240);
  }
}

function gameLoop() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  if (!gameOver) {
    updatePlayer();
    updateBarrels();
  }
  platforms.forEach(drawPlatform);
  ladders.forEach(drawLadder);
  drawDonkey();
  drawPrincess();
  drawPlayer();
  barrels.forEach(drawBarrel);
  drawHUD();
  requestAnimationFrame(gameLoop);
}

gameLoop();
